Assignment 8 deliverables

Files included:
1) Assignment8_Bankruptcy_EDA_Clustering.Rmd
2) references.bib
3) executive_summary.md
4) Assignment8_Bankruptcy_Presentation.pptx

How to run/knit the paper:
1) Put american_bankruptcy.csv in the same folder as the Rmd (or edit data_path in the Rmd).
2) Open the Rmd in RStudio.
3) Install any missing packages when prompted.
4) Click Knit -> Knit to PDF.

Notes:
• The Rmd is written to compute all tables/figures/metrics at knit time.
• The PowerPoint contains slide notes (2 sentences each) and source links in [Sources] blocks.
