const pptxgen = require('pptxgenjs');

// Note: helper exports in this environment are limited; we avoid custom shadow helpers
// and validate layout using /home/oai/share/slides/slides_test.py after generation.

// Basic theme constants
const pptx = new pptxgen();
pptx.layout = 'LAYOUT_WIDE'; // 13.333 x 7.5 in

const THEME = {
  fontHead: 'Calibri',
  fontBody: 'Calibri',
  cText: '2B2B2B',
  cMuted: '6B7280',
  cPrimary: '0F766E',
  cBg: 'FFFFFF',
  cCard: 'F8FAFC',
  cLine: 'E5E7EB',
};

function addTitle(slide, title, subtitle) {
  slide.addText(title, {
    x: 0.7, y: 0.55, w: 12, h: 0.6,
    fontFace: THEME.fontHead,
    fontSize: 34,
    color: THEME.cText,
    bold: true,
  });
  if (subtitle) {
    slide.addText(subtitle, {
      x: 0.7, y: 1.15, w: 12, h: 0.5,
      fontFace: THEME.fontBody,
      fontSize: 16,
      color: THEME.cMuted,
    });
  }
  slide.addShape(pptx.ShapeType.line, {
    x: 0.7, y: 1.7, w: 12.0, h: 0,
    line: { color: THEME.cLine, width: 1 },
  });
}

function addFooter(slide, leftText) {
  slide.addShape(pptx.ShapeType.line, {
    x: 0.7, y: 7.05, w: 12.0, h: 0,
    line: { color: THEME.cLine, width: 1 },
  });
  slide.addText(leftText || 'Assignment 8 — Bankruptcy EDA & Clustering', {
    x: 0.7, y: 7.12, w: 9.5, h: 0.3,
    fontFace: THEME.fontBody,
    fontSize: 10,
    color: THEME.cMuted,
  });
  slide.addText('k-means (k=2)', {
    x: 10.6, y: 7.12, w: 2.1, h: 0.3,
    fontFace: THEME.fontBody,
    fontSize: 10,
    color: THEME.cMuted,
    align: 'right',
  });
}

function addCard(slide, x, y, w, h, title, bodyLines) {
  slide.addShape(pptx.ShapeType.roundRect, {
    x, y, w, h,
    fill: { color: THEME.cCard },
    line: { color: THEME.cLine, width: 1 },
    radius: 8,
  });
  if (title) {
    slide.addText(title, {
      x: x + 0.35, y: y + 0.25, w: w - 0.7, h: 0.35,
      fontFace: THEME.fontHead,
      fontSize: 14,
      color: THEME.cText,
      bold: true,
    });
  }
  if (bodyLines && bodyLines.length) {
    slide.addText(bodyLines.join('\n'), {
      x: x + 0.35, y: y + 0.65, w: w - 0.7, h: h - 0.85,
      fontFace: THEME.fontBody,
      fontSize: 12,
      color: THEME.cText,
      valign: 'top',
    });
  }
}

// --- Slide 1: Title ---
{
  const slide = pptx.addSlide();
  slide.background = { color: THEME.cBg };
  slide.addText('Bankruptcy EDA + K-Means Clustering', {
    x: 0.8, y: 2.2, w: 12, h: 0.8,
    fontFace: THEME.fontHead,
    fontSize: 42,
    color: THEME.cText,
    bold: true,
  });
  slide.addText('Signature Assignment (Lesson 8) — Part B: Presentation', {
    x: 0.8, y: 3.1, w: 12, h: 0.5,
    fontFace: THEME.fontBody,
    fontSize: 18,
    color: THEME.cMuted,
  });
  slide.addShape(pptx.ShapeType.roundRect, {
    x: 0.8, y: 4.0, w: 12.0, h: 2.2,
    fill: { color: THEME.cCard },
    line: { color: THEME.cLine, width: 1 },
    radius: 10,
  });
  slide.addText('Goal', {
    x: 1.2, y: 4.2, w: 2.0, h: 0.3,
    fontFace: THEME.fontHead,
    fontSize: 14,
    bold: true,
    color: THEME.cPrimary,
  });
  slide.addText('Clean the data end-to-end and evaluate whether a 2-cluster k-means model can separate firms that failed from firms that remained alive.', {
    x: 1.2, y: 4.55, w: 11.2, h: 0.8,
    fontFace: THEME.fontBody,
    fontSize: 16,
    color: THEME.cText,
  });
  addFooter(slide, 'Assignment 8 — Bankruptcy EDA & Clustering');

  slide.addNotes(
    'This presentation summarizes the full EDA workflow and the k-means (k=2) clustering model used to approximate bankruptcy status. It is designed to accompany the annotated R Markdown report and highlight key decisions, results, and limitations.\n\n[Sources]\n- https://projecteuclid.org/journals/annals-of-mathematical-statistics/volume-33/issue-1/The-Future-of-Data-Analysis/10.1214/aoms/1177704711.full\n'
  );
}

// --- Slide 2: Dataset overview ---
{
  const slide = pptx.addSlide();
  addTitle(slide, 'Dataset Overview', 'What we modeled and why leakage matters');

  addCard(slide, 0.7, 2.0, 6.1, 2.2, 'Unit of analysis', [
    'Raw data are firm-year observations.',
    'To predict company status, we also build a',
    'company-level table (most recent year per firm).',
  ]);
  addCard(slide, 7.0, 2.0, 5.7, 2.2, 'Target label', [
    'status_label ∈ {alive, failed}',
    'Bankruptcy is rare → strong class imbalance.',
    'We keep stratification in train/test split.',
  ]);

  // Bar chart: alive vs failed (company-level counts)
  const dataChart = [
    {
      name: 'Firms',
      labels: ['Alive', 'Failed'],
      values: [8362, 609],
    },
  ];
  slide.addChart(pptx.ChartType.bar, dataChart, {
    x: 0.7,
    y: 4.55,
    w: 6.1,
    h: 2.2,
    chartColors: ['0F766E'],
    showLegend: false,
    valAxisTitle: 'Count',
    catAxisTitle: 'Status',
    dataLabelPosition: 'outEnd',
  });

  addCard(slide, 7.0, 4.55, 5.7, 2.2, 'Key fields', [
    'company_name (ID)',
    'year (time index)',
    'X1–X18 (numeric financial features)',
    'Feature engineering adds log-size & trend variables.',
  ]);

  addFooter(slide);
  slide.addNotes(
    'The dataset contains firm identifiers, a year, and multiple numeric financial features, with bankruptcy (failed) as a minority class. Because each firm can appear in multiple years, we prevent leakage by splitting at the company level when building the modeling table.\n\n[Sources]\n- https://www.sciencedirect.com/science/article/pii/S0957417417307224\n'
  );
}

// --- Slide 3: EDA checklist ---
{
  const slide = pptx.addSlide();
  addTitle(slide, 'EDA Checklist', 'What we verified before modeling');

  addCard(slide, 0.7, 2.0, 12.0, 4.7, 'Core EDA steps completed', [
    '1) Variable types: identifiers vs. labels vs. numeric predictors',
    '2) Data structure: row/column counts; class imbalance; duplicates',
    '3) Missingness: documented and visualized (missmap + table)',
    '4) Outliers/anomalies: boxplots, extreme quantiles, sanity checks',
    '5) Univariate plots: histograms/boxplots for representative features',
    '6) Multivariate analysis: correlations + PCA visualization',
  ]);

  addFooter(slide);
  slide.addNotes(
    'EDA is used to understand data behavior before modeling, including types, missingness, distributions, and relationships among variables. This follows Tukey’s framing of EDA as an essential step to avoid hidden data issues driving misleading conclusions.\n\n[Sources]\n- https://projecteuclid.org/journals/annals-of-mathematical-statistics/volume-33/issue-1/The-Future-of-Data-Analysis/10.1214/aoms/1177704711.full\n'
  );
}

// --- Slide 4: Preprocessing decisions ---
{
  const slide = pptx.addSlide();
  addTitle(slide, 'Preprocessing Decisions', 'How we handled outliers and scale');

  addCard(slide, 0.7, 2.0, 5.9, 4.7, 'Why preprocessing matters', [
    'K-means uses Euclidean distance.',
    'Skew and extreme outliers can dominate distance.',
    'Mixed scales can cause unstable centroids.',
  ]);

  addCard(slide, 6.8, 2.0, 5.9, 4.7, 'What we did', [
    '• Winsorize numeric features using training-only caps',
    '  (e.g., 1st/99th percentiles) to reduce extreme leverage.',
    '• Standardize numeric predictors (z-scores) using training stats.',
    '• Apply the same caps and scaling to the test set (no leakage).',
  ]);

  addFooter(slide);
  slide.addNotes(
    'Distance-based methods are sensitive to scale and outliers, so we cap extremes and standardize variables using only training information. If missingness were present, principled missing-data methods should be selected based on MAR/MNAR mechanisms rather than ad-hoc deletion.\n\n[Sources]\n- https://academic.oup.com/jrsssc/article/28/1/100/6953842\n- https://pubmed.ncbi.nlm.nih.gov/12090408/\n'
  );
}

// --- Slide 5: Feature engineering ---
{
  const slide = pptx.addSlide();
  addTitle(slide, 'Feature Engineering', 'New variables added for clustering');

  addCard(slide, 0.7, 2.0, 12.0, 4.7, 'Engineered features (examples)', [
    '• Log size proxy: x1_log = log(1 + max(x1, 0)) to reduce scale effects.',
    '• Trend feature: x1_growth = (x1 - lag(x1)) / (|lag(x1)| + 1) within firm.',
    '• Data availability flag: has_prior_year indicates whether lag() exists.',
    '',
    'Rationale: bankruptcy signals can appear as changes over time, and log transforms',
    'can stabilize heavy-tailed financial variables.',
  ]);

  addFooter(slide);
  slide.addNotes(
    'We created at least one new variable and justified it based on common behavior of financial quantities (skewed, heavy-tailed, and trend-driven). Recent research continues to explore nonlinear transformations of financial ratios to improve bankruptcy modeling.\n\n[Sources]\n- https://www.sciencedirect.com/science/article/pii/S0377221725005612\n'
  );
}

// --- Slide 6: Train/test design ---
{
  const slide = pptx.addSlide();
  addTitle(slide, 'Train/Test Split (No Leakage)', 'How we kept evaluation honest');

  addCard(slide, 0.7, 2.0, 12.0, 4.7, 'Leakage controls', [
    '• We split the company-level table so each firm appears in only one split.',
    '• All preprocessing (winsorization caps, scaling) is learned on training data only.',
    '• The test set is used once at the end for performance reporting.',
    '',
    'This prevents “peeking” at the test distribution when transforming features.',
  ]);

  addFooter(slide);
  slide.addNotes(
    'A train/test split is essential for any predictive claim, including when we map unsupervised clusters to labels. Using training-only statistics for preprocessing avoids information leakage that would inflate reported performance.\n\n[Sources]\n- https://www.sciencedirect.com/science/article/pii/S0957417417307224\n'
  );
}

// --- Slide 7: K-means model ---
{
  const slide = pptx.addSlide();
  addTitle(slide, 'K-Means Model (k = 2)', 'Model specification');

  addCard(slide, 0.7, 2.0, 6.1, 4.7, 'Algorithm (high level)', [
    '1) Initialize 2 centroids (multiple random starts)',
    '2) Assign each firm to nearest centroid (Euclidean distance)',
    '3) Update centroids as the mean of assigned points',
    '4) Iterate until assignments stabilize',
  ]);

  addCard(slide, 7.0, 2.0, 5.7, 4.7, 'Implementation choices', [
    '• k = 2 to match {alive, failed}',
    '• nstart ≥ 25 to reduce sensitivity to initialization',
    '• Predict test clusters by nearest training centroids',
    '• Map clusters → labels using training data only',
  ]);

  addFooter(slide);
  slide.addNotes(
    'K-means partitions observations by minimizing within-cluster squared Euclidean distances, and it is sensitive to initialization, so multiple starts are standard practice. We keep k fixed at 2 to align clusters with the two business states, then interpret clusters by their feature profiles.\n\n[Sources]\n- https://academic.oup.com/jrsssc/article/28/1/100/6953842\n- https://www.jstor.org/stable/2346830\n'
  );
}

// --- Slide 8: Cluster interpretation ---
{
  const slide = pptx.addSlide();
  addTitle(slide, 'Cluster Interpretation', 'How we explain what each cluster represents');

  addCard(slide, 0.7, 2.0, 12.0, 4.7, 'Interpretation approach', [
    '• Compare cluster centroids/means on key engineered features (e.g., x1_log, x1_growth).',
    '• Visualize separation in PCA space and inspect overlap between clusters and labels.',
    '• Report the bankruptcy rate inside each cluster on training data.',
    '',
    'In the report, the “cluster diagram” uses PCA + cluster labels to show structure.',
  ]);

  addFooter(slide);
  slide.addNotes(
    'Because high-dimensional clusters are hard to understand directly, we summarize clusters using centroid profiles and visualize them in reduced dimensions (PCA). Cluster validity and interpretability are commonly checked using tools like silhouette widths and stability analyses.\n\n[Sources]\n- https://www.sciencedirect.com/science/article/pii/0377042787901257\n'
  );
}

// --- Slide 9: Evaluation metrics ---
{
  const slide = pptx.addSlide();
  addTitle(slide, 'Model Evaluation on Test Set', 'Precision, recall, accuracy, and F1');

  addCard(slide, 0.7, 2.0, 6.1, 4.7, 'What we compute', [
    '• Precision (PPV): TP / (TP + FP)',
    '• Recall (Sensitivity): TP / (TP + FN)',
    '• Accuracy: (TP + TN) / N',
    '• F1: harmonic mean of precision and recall',
  ]);

  addCard(slide, 7.0, 2.0, 5.7, 4.7, 'How to interpret (imbalance)', [
    '• With rare bankruptcies, accuracy can look “good” even if',
    '  the model never detects failures.',
    '• Precision–recall tradeoffs matter more than accuracy alone.',
    '• We report a confusion matrix and all four metrics.',
    '',
    'Numbers are computed in the R Markdown report when knit.',
  ]);

  addFooter(slide);
  slide.addNotes(
    'We evaluate clusters by mapping them to labels using training data, then computing standard classification metrics on the withheld test set. The class imbalance makes precision and recall particularly important, because a model can achieve high accuracy by predicting only the majority class.\n\n[Sources]\n- https://www.sciencedirect.com/science/article/pii/S0167865509002323\n'
  );
}

// --- Slide 10: Results summary (qualitative) ---
{
  const slide = pptx.addSlide();
  addTitle(slide, 'Results Summary', 'What clustering did well (and didn\'t)');

  addCard(slide, 0.7, 2.0, 12.0, 4.7, 'Key findings', [
    '• K-means identifies broad financial structure, but overlap between alive and failed firms is substantial.',
    '• Performance depends heavily on how clusters are mapped to labels under imbalance.',
    '• The report includes: descriptive table, >=3 graphs, PCA cluster diagram, and full metric set.',
    '',
    'Bottom line: clustering is a useful exploratory baseline, but not a standalone bankruptcy scoring solution.',
  ]);

  addFooter(slide);
  slide.addNotes(
    'The main value of unsupervised clustering here is exploratory: it shows structure and can flag unusual firm profiles without using labels. The bankruptcy prediction literature consistently finds that model choice, feature construction, and imbalance handling drive performance.\n\n[Sources]\n- https://www.sciencedirect.com/science/article/pii/S0957417417307224\n'
  );
}

// --- Slide 11: Limitations ---
{
  const slide = pptx.addSlide();
  addTitle(slide, 'Limitations', 'Why k-means is not a panacea');

  addCard(slide, 0.7, 2.0, 12.0, 4.7, 'Limitations to report', [
    '• K-means assumes roughly spherical clusters and uses Euclidean distance.',
    '• Heavy tails and outliers can still influence results even after winsorization.',
    '• Bankruptcy is rare, so clusters may not align with the minority class.',
    '• Features X1–X18 are unlabeled financial indicators, limiting interpretability.',
  ]);

  addFooter(slide);
  slide.addNotes(
    'These limitations are consistent with well-known clustering challenges: sensitivity to scaling, distributional shape, and the fact that clusters do not necessarily correspond to real-world labels. This motivates evaluating alternative clustering families and supervised baselines for decision use.\n\n[Sources]\n- https://www.sciencedirect.com/science/article/pii/S0167865509002323\n'
  );
}

// --- Slide 12: Future work + close ---
{
  const slide = pptx.addSlide();
  addTitle(slide, 'Future Work & Takeaways', 'Next steps after this course');

  addCard(slide, 0.7, 2.0, 12.0, 4.7, 'Practical next steps', [
    '1) Compare to supervised baselines (logit / Z-score style) for prediction quality.',
    '2) Test richer clustering (mixture models, k-medoids) and validate with silhouette.',
    '3) Add multi-year trend features and test time-aware evaluation designs.',
    '4) If missingness appears in future data, use principled methods (MAR/MNAR theory).',
    '',
    'Takeaway: disciplined EDA + leakage control are non-negotiable for trustworthy analytics.',
  ]);

  addFooter(slide);
  slide.addNotes(
    'Future work follows directly from known results in bankruptcy modeling (classic ratio-based models plus modern reviews) and clustering validation practice. The core course takeaway is that correct preprocessing, leakage prevention, and transparent reporting often matter as much as the modeling algorithm itself.\n\n[Sources]\n- https://www.sciencedirect.com/science/article/pii/S0957417417307224\n- https://www.sciencedirect.com/science/article/pii/0377042787901257\n- https://pubmed.ncbi.nlm.nih.gov/12090408/\n'
  );
}

pptx.writeFile({ fileName: '/mnt/data/assignment8/Assignment8_Bankruptcy_Presentation.pptx' });
